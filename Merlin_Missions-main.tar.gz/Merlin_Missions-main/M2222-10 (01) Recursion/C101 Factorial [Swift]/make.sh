#!/bin/bash
swiftc main.swift -o main
